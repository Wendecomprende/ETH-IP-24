/*
Tunleft funktion dreht bis status "shoot" erreicht ist. (weiss-schwaz-schwarz-schwarz-weiss)
*/
void turnleft(){

  motorR->setSpeed(50);  //motoren für links/rechts eingstellen
  motorL->setSpeed(55);

  motorR->run(FORWARD);  // Anfangsrichtung für den motor links/rechts einstellen
  motorL->run(BACKWARD);
  delay(500); 
  bool conline = false;
  while(conline == false) {
    qtr.readLineBlack(sensorValues);
    updateLineStatus();
    if(sensorValues[1] > 555) {
      conline = true;
      //delay(78);
      motorL->setSpeed(0);
      motorR->setSpeed(0);
    }
  }
}

/*
Tunright funktion dreht bis status "shoot" erreicht ist. (weiss-schwaz-schwarz-schwarz-weiss)
*/
void turnright(){

  motorR->setSpeed(55);  //motoren für links/rechts eingstellen
  motorL->setSpeed(50);

  motorR->run(BACKWARD);  // Anfangsrichtung für den motor links/rechts einstellen
  motorL->run(FORWARD);
  delay(500);
  bool conline =  false;
  while(conline == false) {
    qtr.readLineBlack(sensorValues);
    updateLineStatus();
    if(sensorValues[3] > 555) {
      conline = true;
      //delay(78);
      motorR->setSpeed(0);
      motorL->setSpeed(0);
    }
  }
}

/*
turntime funktion dreht sich eine gewisse zeit in angegebene Richtung
*/
void turntime(int time, bool right){///IRGENDWO DELAY EINBAUEN, DASS SABRINA ZENTRIERT

  motorR->setSpeed(50);  //motoren für links/rechts eingstellen
  motorL->setSpeed(50);
  if(right){
    motorR->run(BACKWARD);  // Anfangsrichtung für den motor links/rechts einstellen
    motorL->run(FORWARD);
  }else{
    motorR->run(FORWARD);  // Anfangsrichtung für den motor links/rechts einstellen
    motorL->run(BACKWARD);
  }
  
  delay(time);
  
  motorR->setSpeed(0);  //motoren für links/rechts eingstellen
  motorL->setSpeed(0);
}

