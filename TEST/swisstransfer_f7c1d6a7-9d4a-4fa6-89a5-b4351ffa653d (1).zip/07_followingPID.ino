
#include "03_Defines.h"

#define BLACK_THRESHOLD 555  // Define threshold for black detection
#define WHITE_THRESHOLD 555  // Define threshold for white detection

bool stopFlag;  
int position;
double controlSignal;
double speed = 0.37 * defaultSpeed;


bool allSensorsDetectBlack() {
  int counter = 0;
  for (uint8_t i = 0; i < SensorCount; i++) {
    if (sensorValues[i] > BLACK_THRESHOLD) {  
      counter++;
    }
  }
  return (counter == SensorCount);
}

bool allSensorsDetectWhite() {
  int counter = 0;
  for (uint8_t i = 0; i < SensorCount; i++) {
    if (sensorValues[i] < WHITE_THRESHOLD) {  
      counter++;
    }
  }
  return (counter == SensorCount);
}

void driveBack() {
  motorR->setSpeed(25);   
  motorL->setSpeed(25);

  motorR->run(BACKWARD);
  motorL->run(BACKWARD);

  // Keep driving back until all sensors detect black
  while (!allSensorsDetectBlack()) {
    delay(10); // Small delay to avoid excessive CPU usage
  }

  motorR->setSpeed(0);   
  motorL->setSpeed(0);
  motorR->run(RELEASE);
  motorL->run(RELEASE);
}

void followingPIDBACK() {
  stopFlag = false;  

  while (!stopFlag) {
    position = qtr.readLineBlack(sensorValues);
    controlSignal = updatePI(&pi, position);

    // Calculate and constrain motor speeds
    int leftSpeed = constrain((int)(speed - controlSignal), -255, 255);
    int rightSpeed = constrain((int)(speed + controlSignal), -255, 255);

    motorR->setSpeed((abs(rightSpeed) > 24 ? rightSpeed : 24));  
    motorL->setSpeed((abs(leftSpeed) > 24 ? leftSpeed : 24));
    
    motorR->run(BACKWARD);
    motorL->run(BACKWARD);

    // Check if all sensors detect white
    if (allSensorsDetectBlack()) {
      stopFlag = true;  
      motorR->setSpeed(0);  
      motorL->setSpeed(0);
      motorR->run(RELEASE);
      motorL->run(RELEASE);
    }
    delay(10); // Small delay for smoother operation
  }
}


void followingPID() {
  //driveBack();  // Drive back first
  //Backward(50, 400);
  followingPIDBACK();
  stopFlag = false;  

  while (!stopFlag) {
    position = qtr.readLineBlack(sensorValues);
    controlSignal = updatePI(&pi, position);

    // Calculate and constrain motor speds
    int leftSpeed = constrain((int)(speed + controlSignal), -255, 255);
    int rightSpeed = constrain((int)(speed - controlSignal), -255, 255);

    motorR->setSpeed((abs(rightSpeed) > speed ? rightSpeed : speed));  
    motorL->setSpeed((abs(leftSpeed) > speed ? leftSpeed : speed));
    
    motorR->run(FORWARD);
    motorL->run(FORWARD);

    // Check if all sensors detect white
    if (allSensorsDetectWhite()) {
      stopFlag = true;  
      motorR->setSpeed(0);  
      motorL->setSpeed(0);
      motorR->run(RELEASE);
      motorL->run(RELEASE);
    }
    delay(10); // Small delay for smoother operation
  }
  delay(100);//Backward(40, 250);
  followingPIDBACK();
}
